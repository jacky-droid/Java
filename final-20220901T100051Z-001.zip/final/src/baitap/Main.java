package baitap;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	
	
	public static void main(String[] args) {
		ArrayList<NganHang> DSNganHang = new ArrayList<NganHang>();
		DSNganHang.add(new NganHang());
		DSNganHang.add(new NganHang());
		DSNganHang.add(new NganHang());
		
		
		DSNganHang.get(0).setMaChiNhanh("1");
		DSNganHang.get(1).setMaChiNhanh("2");
		DSNganHang.get(2).setMaChiNhanh("3");
		
		DSNganHang.get(0).setTenChiNhanh("chi nhanh a");
		DSNganHang.get(1).setTenChiNhanh("chi nhanh b");
		DSNganHang.get(2).setTenChiNhanh("chi nhanh c");
		
		DSNganHang.get(0).setDiaChi("12w");
		DSNganHang.get(1).setDiaChi("15q");
		DSNganHang.get(2).setDiaChi("25f");
		
		DSNganHang.get(0).setDSKhachHang(new ArrayList<KhachHang>());
		DSNganHang.get(1).setDSKhachHang(new ArrayList<KhachHang>());
		DSNganHang.get(2).setDSKhachHang(new ArrayList<KhachHang>());
		
		System.out.println("truoc khi nhap");
		xuatKhachHang(DSNganHang);
		
		nhapKhachHang(DSNganHang);
		
		
		System.out.println("sau khi nhap");
		
		xuatKhachHang(DSNganHang);
		xuatChiNhanh(DSNganHang);
    }
		
	private static void nhapChiNhanh(ArrayList<NganHang> DSNganHang) {	
		System.out.println("nhap so luong: ");
		Scanner scanner = new Scanner(System.in);		
		int n = scanner.nextInt(); 
		scanner.nextLine();
		NganHang nganHangTemp;
		
		for(int i = 0; i < n; i++) {
			nganHangTemp = new NganHang();
			System.out.println("nhap thong tin chi nhanh thu " + i);
			
			System.out.println("nhap ma chi nhanh");
			nganHangTemp.setMaChiNhanh(ToolCheck.nhapString());
			
			System.out.println("nhap ten chi nhanh");
			nganHangTemp.setTenChiNhanh(ToolCheck.nhapString());
			
			System.out.println("nhap dia chi");
			nganHangTemp.setDiaChi(ToolCheck.nhapString());
			
			nganHangTemp.setDSKhachHang(new ArrayList<KhachHang>());
			DSNganHang.add(nganHangTemp);
		}
	}
	
	private static void xuatChiNhanh(ArrayList<NganHang> DSNganHang) {
		for(int i = 0; i < DSNganHang.size(); i++){
			System.out.println("ma chi nhanh: " + DSNganHang.get(i).getMaChiNhanh());
			System.out.println("ten chi nhanh: " + DSNganHang.get(i).getTenChiNhanh());
		}
	}
	
	private static void xuatKhachHang(ArrayList<NganHang> DSNganHang) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("nhap id ngan hang");
		String idnh = scanner.nextLine();
		for(int i = 0; i < DSNganHang.size(); i++) {
			if(DSNganHang.get(i).getMaChiNhanh().equals(idnh)) {
				ArrayList<KhachHang> DSKhachHang = DSNganHang.get(i).getDSKhachHang();
				for(int j = 0; j < DSKhachHang.size(); j++) {
					System.out.println("ma khach hang: " + DSKhachHang.get(j).getMaKhachHang());
					System.out.println("ten khach hang: " + DSKhachHang.get(j).getTenKhachHang());
				}
				break;
			}
			
		}
	}
	
	private static void nhapKhachHang(ArrayList<NganHang> DSNganHang) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("nhap id ngan hang");
		String idnh = scanner.nextLine();
		System.out.println("nhap so luong");
		int n = scanner.nextInt();
		scanner.nextLine();
		
		
		for(int i = 0; i < DSNganHang.size(); i++) {
			if(DSNganHang.get(i).getMaChiNhanh().equals(idnh)) {
				KhachHang KhachHangTemp;
				DiaChi diaChiTemp;
				ArrayList<KhachHang> DSKhachHang = DSNganHang.get(i).getDSKhachHang();
				for(int j = 0; j < n; j++) {
					 KhachHangTemp = new KhachHang();
					 diaChiTemp = new DiaChi();
					 System.out.println("nhap ma khach hang: ");
					 KhachHangTemp.setMaKhachHang(ToolCheck.nhapString());
					 
					 System.out.println("nhap ten khach hang: ");
					 KhachHangTemp.setTenKhachHang(ToolCheck.nhapString());
					 
					 System.out.println("nhap dia chi khach hang: ");
					 System.out.println("nhap thon: ");
					 diaChiTemp.setThon(ToolCheck.nhapString());
					 
					 System.out.println("nhap xa/phuong: ");
					 diaChiTemp.setXaPhuong(ToolCheck.nhapString());
					 
					 System.out.println("nhap quan/huyen: ");
					 diaChiTemp.setQuanHuyen(ToolCheck.nhapString());
					 
					 System.out.println("nhap tinh/thanhpho: ");
					 diaChiTemp.setTinhThanhPho(ToolCheck.nhapString());
					 
					 KhachHangTemp.setDiaChi(diaChiTemp);
					 

					 DSKhachHang.add(KhachHangTemp);
				}
				break;
			}
			
		}
	}
	
				
			
			
		
		
		
	


}	


