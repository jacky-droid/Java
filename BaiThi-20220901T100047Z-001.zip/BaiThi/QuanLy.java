package BaiThi;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class QuanLy {
	private List<ChiNhanh>	danhsachChiNhanh = new ArrayList<>();
	private List<KhachHang> khachhang = new ArrayList<>();
	private List<TaiKhoan> taikhoan = new ArrayList<>();
	private List<GiaoDich> giaodich = new ArrayList<>();
	private List<DiaChi> diachi = new ArrayList<>();
	Scanner sc = new Scanner(System.in);
	ChiNhanh chinhanh = new ChiNhanh();
	KhachHang KH  = new KhachHang();
	DiaChi DC = new DiaChi();
	public QuanLy() {
		
	}
	
	public void themtaikhoan(TaiKhoan taikhoan) {
		this.taikhoan.add(taikhoan);
	}
	
	public void themkhachhang(KhachHang khachhang) {
		this.khachhang.add(khachhang);
	}
	
	public void nhapchinhanh(int X) {
		System.out.println("nhap ma chi nhanh: ");
		chinhanh.setMaChiNhanh(sc.nextLine());
		System.out.println("nhap ten chi nhanh: ");
		chinhanh.setTenChiNhanh(sc.nextLine());
		System.out.println("nhap dia chi chi nhanh");
		chinhanh.setdiaChiChiNhanh(sc.nextLine());
		danhsachChiNhanh.add(chinhanh);
		System.out.println("nhap so khach hang cua chi nhanh");
		X = sc.nextInt(); sc.nextLine();
		danhsachChiNhanh.add(chinhanh);
	}
	
	public void nhapkhachhang() {
		System.out.println("nhap ma khach hang");
		KH.setMaKhachHang(sc.nextLine());
		System.out.println("nhap ten khach hang");
		KH.setTenKhacHang(sc.nextLine());
		System.out.println("nhap dia chi");
		KH.setDiachi(DC);
		khachhang.add(KH);
	}
	
	public void nhapdiachi() {
		System.out.println("nhap thon");
		DC.setThon(sc.nextLine());
		System.out.println("nhap xaOrPhuong");
		DC.setXaOrPhuong(sc.nextLine());
		System.out.println("nhap quanOrHuyen");
		DC.setQuanOrHuyen(sc.nextLine());
		System.out.println("nhap tinh");
		DC.setTinh(sc.nextLine());
		System.out.println("nhap thanh pho");
		DC.setThanhPho(sc.nextLine());
		diachi.add(DC);
	}
	
	public void timkiem(String X) {
		X = X.trim();
		for (int i=0; i<this.khachhang.size(); i++) {
			if(this.khachhang.get(i).equals(X)) {
				System.out.println(this.khachhang.get(i));
		}
		}
}
	public double guitien(Double X, String Y) {
		System.out.println("nhap so tien can gui");
		X = sc.nextDouble(); sc.nextLine();
		System.out.println("nhap tai khoan can gui");
		Y = Y.trim();
		Y=sc.nextLine();
		for(int i=0; i<this.khachhang.size();i++) {
			if(this.khachhang.get(i).equals(Y)) {
				System.out.println("So tien da duoc nhan so du la:");
				return this.taikhoan.get(i).getSoDu()+X;
			}	
		}
		return X;
	}
		
		public double guitienorruttien(Double X, String Y, String Z) {
			System.out.println("nhap so tien can gui");
			X = sc.nextDouble(); sc.nextLine();
			System.out.println("nhap tai khoan can gui");
			Y = Y.trim();
			Y=sc.nextLine();
			for(int i=0; i<this.khachhang.size();i++) {
				if(this.khachhang.get(i).equals(Y)) {
				System.out.println("gui hay rut");
				Z = Z.trim();
				Z = sc.nextLine();
				if(this.giaodich.get(i).getLoaiGiaoDich() == "W") {
					System.out.println("So tien da duoc nhan so du la:");
					return this.taikhoan.get(i).getSoDu()+X;
				}
				else 
				{System.out.println("So tien da duoc nhan so du la:");
				return this.taikhoan.get(i).getSoDu()-X;
				}	
				}
			}
			return X;
	}
	public void showGD(String X) {
		X=X.trim();
		System.out.println("nhap chi nhanh can in");
		for (int i=0; i<this.danhsachChiNhanh.size();i++)
			if(this.danhsachChiNhanh.get(i).equals(X)) {
				for(int i2=0; i<this.khachhang.size();i++)
			for(int i1 =0; i1<this.giaodich.size();i1++)
				System.out.println(this.giaodich.get(i1));
	}
			else System.out.println("khong tim thay chi nhanh");
	}
	
	public void sapxepsodutaikhoan() {
	//Collections.sort(taikhoan, (a, b) -> a.getSoDu().compareTo(b.getSoDu()));
	}
	
	public void nguoicogiaodichnhieunhat(String X) {
		for (int i=0;i<this.taikhoan.size();i++)
		{
			for(int i1=0; i<this.giaodich.size();i++) {
				i1++;
				if(i1==this.giaodich.size()){
					System.out.println(this.khachhang.get(i).getTenKhacHang());
				}
			}
		}
	}
}
