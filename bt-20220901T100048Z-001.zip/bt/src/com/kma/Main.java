package com.kma;
import java.util.ArrayList;
public class Main {
    public static void main(String[] args) {
    	// TODO Auto-generated method stub
    	 CongTy congTy = new CongTy("CT01", "SOLID", "17 Cong Hoa", new ArrayList<SanPham>());
         ArrayList<KhachHang> dsKhachHang = new ArrayList<KhachHang>();
         dsKhachHang.add(new KhachHang("KH1", "tien anh", "100 Cong Hoa")); 
         ArrayList<HoaDon> dsHoaDon = new ArrayList<HoaDon>();
         
         System.out.println("in thong tin doanh nghiep");
         inThongTinDoanhNgiep(congTy);
         System.out.println("nhap san pham");
         nhapSanPham(congTy);
         System.out.println("mua hang");
         muaHang(congTy, dsKhachHang.get(0), dsHoaDon);
         System.out.println("in hoa don");
         InHoaDon(dsKhachHang.get(0), dsHoaDon);
         System.out.println("in hoa don lon nhat");
         InHoaDonLonNhat(dsKhachHang, dsHoaDon);
     }
     //a
     public static void inThongTinDoanhNgiep(CongTy congTy){
         
         System.out.println("Ma Cong Ty: " + congTy.getMaCongTy());
         System.out.println("Ten Cong Ty: " + congTy.getTenCongTy());
         System.out.println("Dia Chi: " + congTy.getDiaChi());
         
     }
     //b
     public static void nhapSanPham(CongTy congTy) {
         ArrayList<SanPham> dsSanPham = new ArrayList<SanPham>();
         dsSanPham.add(new SanPham("SP01", "RAM", 50, 100));
         dsSanPham.add(new SanPham("SP02", "CPU", 30, 50));
         dsSanPham.add(new SanPham("SP03", "VGA", 40, 90));
         
         int n = 3;
         for(int i = 0; i < n; i++){
             congTy.getDsSanPham().add(dsSanPham.get(i));
             System.out.println("Ma San Pham: " + dsSanPham.get(i).getMaSanPham());
             System.out.println("Ma Ten Pham: " + dsSanPham.get(i).getTenSanPham());
             System.out.println("Gia Nhap: " + dsSanPham.get(i).getGiaNhap());
             System.out.println("Gia Ban Ra: " + dsSanPham.get(i).getGiaBanRa());
         }
     }
     //c
     public static void muaHang(CongTy congTy, KhachHang khachHang, ArrayList<HoaDon> dsHoaDon) {
         ArrayList<SanPham> dsSanPham = congTy.getDsSanPham();
         ArrayList<SanPhamMua> dsSanPhamMua = new ArrayList<SanPhamMua>();
         int n = 2;
         for(int i = 0; i < n; i++){
             dsSanPhamMua.add(new SanPhamMua(dsSanPham.get(0).getMaSanPham(), dsSanPham.get(0).getTenSanPham(), dsSanPham.get(0).getGiaBanRa(), 3));
             dsSanPhamMua.add(new SanPhamMua(dsSanPham.get(1).getMaSanPham(), dsSanPham.get(1).getTenSanPham(), dsSanPham.get(0).getGiaBanRa(), 1));
             dsHoaDon.add(new HoaDon(String.format("%02d", dsHoaDon.size()), khachHang.getMaKhachHang(), dsSanPhamMua));
         }
     }
     //d
     private static void InHoaDon(KhachHang khachHang, ArrayList<HoaDon> dsHoaDon){
         String maKhachHang = khachHang.getMaKhachHang();
         for(int i = 0; i < dsHoaDon.size(); i++){
             if(dsHoaDon.get(i).getMaKhachHang().equals(maKhachHang)){
                 ArrayList<SanPhamMua> dsSanPhamMua = dsHoaDon.get(i).getDSSanPhamMua();
                 for(int j = 0; j < dsSanPhamMua.size(); j++){
                	 
                     System.out.println("Ma San Pham:" + dsSanPhamMua.get(j).getMaSanPham() );
                     System.out.println("Ten San Pham:" + dsSanPhamMua.get(j).getTenSanPham() );
                     int tongGiaTri = dsSanPhamMua.get(j).getGiaBan()*dsSanPhamMua.get(j).getSoLuong();
                     System.out.println("Tong Gia Tri:" + tongGiaTri);
                 }
                 
             }
         }
     }
     //e
     private static void InHoaDonLonNhat(ArrayList<KhachHang> dsKhachHang, ArrayList<HoaDon> dsHoaDon){
         int max = 0;
         int maxIndex = 0;
         for(int i = 0; i < dsKhachHang.size(); i++){
             String maKhachHang = dsKhachHang.get(i).getMaKhachHang();
             for(int j = 0; j < dsHoaDon.size(); j++){
                 if(dsHoaDon.get(j).getMaKhachHang().equals(maKhachHang)){
                     int tongGiaTri = 0;
                     ArrayList<SanPhamMua> dsSanPhamMua = dsHoaDon.get(j).getDSSanPhamMua();       
                     for(int k = 0; k < dsSanPhamMua.size(); k++){
                         tongGiaTri += (dsSanPhamMua.get(k).getGiaBan()*dsSanPhamMua.get(k).getSoLuong());
                     }
                     if(tongGiaTri > max){
                         max = tongGiaTri;
                         maxIndex = j;
                     }
                 }
                 
             }
             System.out.println("Ma Hoa Don: " + dsHoaDon.get(maxIndex).getMaHoaDon());
             System.out.println("Ma Hoa Don: " + dsHoaDon.get(maxIndex).getMaKhachHang());
             System.out.println("Tong Gia Tri: " + max);
                     }
                     
         }
     }

