package baitap;

import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MaximizeAction;



import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;

import java.text.SimpleDateFormat;


public class ChucNang {
	Scanner sc = new Scanner(System.in);
	ArrayList<NganHang> DSNganHang = new ArrayList<NganHang>();
	ArrayList<KhachHang> DSKhachHang = new ArrayList<KhachHang>();
	public static final String DATE_FORMAT_NOW = "yyyy-MM-dd HH:mm:ss";

	public static String now() {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
		return sdf.format(cal.getTime());
	}
	
	
	public  void nhapChiNhanh(ArrayList<NganHang> DSNganHang) {	
		System.out.println("nhap so luong: ");
				
		int n = sc.nextInt(); 
		sc.nextLine();
		NganHang nganHangTemp;
		
		for(int i = 0; i < n; i++) {
			nganHangTemp = new NganHang();
			System.out.println("nhap thong tin chi nhanh thu " + i);
			
			System.out.println("nhap ma chi nhanh");
			nganHangTemp.setMaChiNhanh(ToolCheck.nhapString());
			
			System.out.println("nhap ten chi nhanh");
			nganHangTemp.setTenChiNhanh(ToolCheck.nhapString());
			
			System.out.println("nhap dia chi");
			nganHangTemp.setDiaChi(ToolCheck.nhapString());
			
			nganHangTemp.setDSKhachHang(new ArrayList<KhachHang>());
			DSNganHang.add(nganHangTemp);
		}
	}
	
	public  void xuatChiNhanh(ArrayList<NganHang> DSNganHang) {
		for(int i = 0; i < DSNganHang.size(); i++){
			System.out.println("ma chi nhanh: " + DSNganHang.get(i).getMaChiNhanh());
			System.out.println("ten chi nhanh: " + DSNganHang.get(i).getTenChiNhanh());
		}
	}
	
	public  void xuatKhachHang(ArrayList<NganHang> DSNganHang) {
		
		System.out.println("nhap id ngan hang");
		String idnh = sc.nextLine();
		for(int i = 0; i < DSNganHang.size(); i++) {
			if(DSNganHang.get(i).getMaChiNhanh().equals(idnh)) {
				ArrayList<KhachHang> DSKhachHang = DSNganHang.get(i).getDSKhachHang();
				for(int j = 0; j < DSKhachHang.size(); j++) {
					System.out.println("ma khach hang: " + DSKhachHang.get(j).getMaKhachHang());
					System.out.println("ten khach hang: " + DSKhachHang.get(j).getTenKhachHang());
					
					
				}
				break;
			}
			
		}
	}
	
	public  void nhapKhachHang(ArrayList<NganHang> DSNganHang) {
		
		System.out.println("nhap id ngan hang");
		String idnh = sc.nextLine();
		
		System.out.println("nhap so luong");
		int n = sc.nextInt();
		sc.nextLine();
		
		for(int i = 0; i < DSNganHang.size(); i++) {
			if(DSNganHang.get(i).getMaChiNhanh().equals(idnh)) {
				KhachHang khachHangTemp;
				DiaChi diaChiTemp;
				ArrayList<KhachHang> DSKhachHang = DSNganHang.get(i).getDSKhachHang();
				for(int j = 0; j < n; j++) {
					 khachHangTemp = new KhachHang();
					 diaChiTemp = new DiaChi();
					 System.out.println("nhap ma khach hang: ");
					 khachHangTemp.setMaKhachHang(ToolCheck.nhapString());
					 
					 System.out.println("nhap ten khach hang: ");
					 khachHangTemp.setTenKhachHang(ToolCheck.nhapString());
					 
					 System.out.println("nhap dia chi khach hang: ");
					 System.out.println("nhap thon: ");
					 diaChiTemp.setThon(ToolCheck.nhapString());
					 
					 System.out.println("nhap xa/phuong: ");
					 diaChiTemp.setXaPhuong(ToolCheck.nhapString());
					 
					 System.out.println("nhap quan/huyen: ");
					 diaChiTemp.setQuanHuyen(ToolCheck.nhapString());
					 
					 System.out.println("nhap tinh/thanhpho: ");
					 diaChiTemp.setTinhThanhPho(ToolCheck.nhapString());
					 
					 khachHangTemp.setDiaChi(diaChiTemp);
					 
					 khachHangTemp.setDSTaiKhoan(new ArrayList<TaiKhoan>());

					 DSKhachHang.add(khachHangTemp);
				}
				break;
			}
			
		}
	}
	public  void nhapTaiKhoan (ArrayList<NganHang> DSNganHang) {		
		
		System.out.println("nhap id ngan hang");
		String maNganHang = sc.nextLine();
		//tim ngan hang
		NganHang nganHangTemp = null;
		for(int i = 0; i < DSNganHang.size(); i++) {
			if(maNganHang.equals(DSNganHang.get(i).getMaChiNhanh())){
				nganHangTemp = DSNganHang.get(i);
			}
		}
		//neu ngan hang khong ton tai
		if(nganHangTemp == null) {
			System.out.println("ngan hang ban nhap khong ton tai");
			return;
		}
		
		System.out.println("nhap id khach hang");
		String maKhachHang = sc.nextLine();
		//tim khach  hang
		KhachHang khachHangTemp = null;
		for(int i = 0; i < nganHangTemp.getDSKhachHang().size(); i++) {
			String mkh = nganHangTemp.getDSKhachHang().get(i).getMaKhachHang();
			if(maKhachHang.equals(mkh)){
				khachHangTemp = nganHangTemp.getDSKhachHang().get(i);
			}
		}
		//neu khach hang khong ton tai
		if(khachHangTemp == null) {
			System.out.println("khach hang ban nhap khong ton tai");
			return;
		}
		
		System.out.println("nhap so luong");
		
		int soLuong = sc.nextInt();
		//nhap tai khoan
		TaiKhoan taiKhoanTemp = null;
		for(int i = 0; i < soLuong; i++) {
			taiKhoanTemp = new TaiKhoan();
			System.out.println("nhap so tai khoan: ");
			taiKhoanTemp.setSoTaiKhoan(ToolCheck.nhapString());
			taiKhoanTemp.setSoDu(0);
			khachHangTemp.getDSTaiKhoan().add(taiKhoanTemp);
		}
		
		
	}

	public void GuiRutTien(ArrayList<NganHang> DSNganHang) {
		
		System.out.println("nhap id ngan hang");
		String maNganHang = sc.nextLine();
		//tim ngan hang
		NganHang nganHangTemp = null;
		for(int i = 0; i < DSNganHang.size(); i++) {
			if(maNganHang.equals(DSNganHang.get(i).getMaChiNhanh())){
				nganHangTemp = DSNganHang.get(i);
			}
		}
		//neu ngan hang khong ton tai
		if(nganHangTemp == null) {
			System.out.println("ngan hang ban nhap khong ton tai");
			return;
		}
		
		System.out.println("nhap id khach hang");
		String maKhachHang = sc.nextLine();
		//tim khach hang
		KhachHang khachHangTemp = null;
		for(int i = 0; i < nganHangTemp.getDSKhachHang().size(); i++) {
			String mkh = nganHangTemp.getDSKhachHang().get(i).getMaKhachHang();
			if(maKhachHang.equals(mkh)){
				khachHangTemp = nganHangTemp.getDSKhachHang().get(i);
			}
		}
		//neu khach hang khong ton tai
		if(khachHangTemp == null) {
			System.out.println("khach hang ban nhap khong ton tai");
			return;
		}
		
		System.out.println("nhap id tai khoan");
		String maTaiKhoan = sc.nextLine();
		//tim tai khoan
		TaiKhoan taiKhoanTemp = null;
		for(int i = 0; i < khachHangTemp.getDSTaiKhoan().size(); i++) {
			String mtk = khachHangTemp.getDSTaiKhoan().get(i).getSoTaiKhoan();
			if(maTaiKhoan.equals(mtk)){
				taiKhoanTemp = khachHangTemp.getDSTaiKhoan().get(i);
			}
		}
		//neu tai khoan khong ton tai
		if(taiKhoanTemp == null) {
			System.out.println("tai khoan ban nhap khong ton tai");
			return;
		}
		
		System.out.println("chon loai giao dich (D: gui; W: rut)");
		String luaChon = sc.nextLine();
		if(luaChon.equals("w")) {
			System.out.println("xin hay nhap so tien ban muon rut");
			double soTien = sc.nextDouble();
			if(soTien > taiKhoanTemp.getSoDu()) {
				System.out.println("so du cua ban khong du de rut");
			}
			else {
				taiKhoanTemp.setSoDu(taiKhoanTemp.getSoDu()-soTien);
				GiaoDich giaoDichMoi = new GiaoDich();
				int soGiaoDich = taiKhoanTemp.getDSGiaoDich().size();
				giaoDichMoi.setMaGiaoDich("gd" + soGiaoDich);
				giaoDichMoi.setNgayGiaoDich(now());
				giaoDichMoi.setLoaiGiaoDich("w");
				giaoDichMoi.setSoTienGiaoDich(soTien);
				taiKhoanTemp.getDSGiaoDich().add(giaoDichMoi);
			}
		}
		else {
			System.out.println("xin hay nhap so tien ban muon gui");
			double soTien = sc.nextDouble();
			//them tien vao so du
			taiKhoanTemp.setSoDu(taiKhoanTemp.getSoDu()+soTien);
			//tao lich su giao dich moi
			GiaoDich giaoDichMoi = new GiaoDich();
			int soGiaoDich = taiKhoanTemp.getDSGiaoDich().size();
			giaoDichMoi.setMaGiaoDich("gd" + soGiaoDich);
			giaoDichMoi.setNgayGiaoDich(now());
			giaoDichMoi.setLoaiGiaoDich("d");
			giaoDichMoi.setSoTienGiaoDich(soTien);
			taiKhoanTemp.getDSGiaoDich().add(giaoDichMoi);
			
		}
		
		System.out.println(taiKhoanTemp.getDSGiaoDich().size());
		for(int i = 0; i < taiKhoanTemp.getDSGiaoDich().size(); i++) {
			
			System.out.println(taiKhoanTemp.getDSGiaoDich().get(i).getMaGiaoDich());
			System.out.println(taiKhoanTemp.getDSGiaoDich().get(i).getNgayGiaoDich());
			System.out.println(taiKhoanTemp.getDSGiaoDich().get(i).getSoTienGiaoDich());
			System.out.println(taiKhoanTemp.getDSGiaoDich().get(i).getLoaiGiaoDich());
		}
		
	}
				
			
	public void inGiaoDich(ArrayList<NganHang> DSNganHang) {
		Scanner sc = new Scanner(System.in);
		System.out.println("nhap id ngan hang");
		String maNganHang = sc.nextLine();
		//tim ngan hang
		NganHang nganHangTemp = null;
		for(int i = 0; i < DSNganHang.size(); i++) {
			if(maNganHang.equals(DSNganHang.get(i).getMaChiNhanh())){
				nganHangTemp = DSNganHang.get(i);
				break;
			}
		}
		//neu ngan hang khong ton tai
		if(nganHangTemp == null) {
			System.out.println("ngan hang ban nhap khong ton tai");
			return;
		}
		
		for(int i = 0; i < nganHangTemp.getDSKhachHang().size(); i++) {
			KhachHang khachHangTemp = nganHangTemp.getDSKhachHang().get(i);
			System.out.println("khach hang: "+khachHangTemp.getTenKhachHang());
			for(int j = 0; j < khachHangTemp.getDSTaiKhoan().size(); j++) {
				TaiKhoan taiKhoanTemp = khachHangTemp.getDSTaiKhoan().get(j);
				System.out.println("tai khoan: "+taiKhoanTemp.getSoTaiKhoan());
				System.out.println("danh sach giao dich");
				for(int k = 0; k < taiKhoanTemp.getDSGiaoDich().size(); k++) {
					GiaoDich giaoDichTemp = taiKhoanTemp.getDSGiaoDich().get(k);
					System.out.println(giaoDichTemp.getMaGiaoDich());
					System.out.println(giaoDichTemp.getNgayGiaoDich());
					System.out.println(giaoDichTemp.getSoTienGiaoDich());
					System.out.println(giaoDichTemp.getLoaiGiaoDich());
					
				}
			}
		}
	}
	
	public void inTaiKhoanCoSoDuLonNhat(ArrayList<NganHang> DSNganHang) {
		Scanner sc = new Scanner(System.in);
		System.out.println("nhap id ngan hang");
		String maNganHang = sc.nextLine();
		//tim ngan hang
		NganHang nganHangTemp = null;
		for(int i = 0; i < DSNganHang.size(); i++) {
			if(maNganHang.equals(DSNganHang.get(i).getMaChiNhanh())){
				nganHangTemp = DSNganHang.get(i);
				break;
			}
		}
		//neu ngan hang khong ton tai
		if(nganHangTemp == null) {
			System.out.println("ngan hang ban nhap khong ton tai");
			return;
		}
		
		for(int i = 0; i < nganHangTemp.getDSKhachHang().size(); i++) {
			KhachHang khachHangTemp = nganHangTemp.getDSKhachHang().get(i);
			System.out.println("khach hang: "+khachHangTemp.getTenKhachHang());
			int indexMax = 0;
			double max = 0;
			for(int j = 0; j < khachHangTemp.getDSTaiKhoan().size(); j++) {
				TaiKhoan taiKhoanTemp = khachHangTemp.getDSTaiKhoan().get(j);
				if(taiKhoanTemp.getSoDu() > max) {
					max = taiKhoanTemp.getSoDu();
					indexMax = j;
				}
			}
			System.out.println(khachHangTemp.getDSTaiKhoan().get(indexMax).getSoTaiKhoan());
		}
	}
	
	public  void inTangDungTheoTongSoDu(ArrayList<NganHang> DSNganHang) {
		Scanner sc = new Scanner(System.in);
		System.out.println("nhap id ngan hang");
		String maNganHang = sc.nextLine();
		//tim ngan hang
		NganHang nganHangTemp = null;
		for(int i = 0; i < DSNganHang.size(); i++) {
			if(maNganHang.equals(DSNganHang.get(i).getMaChiNhanh())){
				nganHangTemp = DSNganHang.get(i);
				break;
			}
		}
		//neu ngan hang khong ton tai
		if(nganHangTemp == null) {
			System.out.println("ngan hang ban nhap khong ton tai");
			return;
		}
		
		class TongSoDu{
			int index;
			double tongSoDu;
			public int getIndex() {
				return index;
			}
			public void setIndex(int index) {
				this.index = index;
			}
			public double getTongSoDu() {
				return tongSoDu;
			}
			public void setTongSoDu(double tongSoDu) {
				this.tongSoDu = tongSoDu;
			}
			
			public void themSoDu(double soTien) {
				this.tongSoDu += soTien;
			}
			
			public TongSoDu(int index, double tongSoDu) {
				super();
				this.index = index;
				this.tongSoDu = tongSoDu;
			}
			
			
			
			
		}
		
		ArrayList<TongSoDu> dsTongSoDu = new ArrayList<TongSoDu>();
		
		for(int i = 0; i < nganHangTemp.getDSKhachHang().size(); i++) {
			KhachHang khachHangTemp = nganHangTemp.getDSKhachHang().get(i);
			
			TongSoDu tongSoDuTemp = new TongSoDu(i, 0);
			for(int j = 0; j < khachHangTemp.getDSTaiKhoan().size(); j++) {
				TaiKhoan taiKhoanTemp = khachHangTemp.getDSTaiKhoan().get(j);
				tongSoDuTemp.themSoDu(taiKhoanTemp.getSoDu());
			}
			dsTongSoDu.add(tongSoDuTemp);
			
		}
		

		
		
		
		Collections.sort(dsTongSoDu,new Comparator<TongSoDu>() {
            @Override
            public int compare(TongSoDu o1, TongSoDu o2) {
                if(o1.getTongSoDu() > o2.getTongSoDu())
                	return 1;
                else if(o1.getTongSoDu() < o2.getTongSoDu())
                	return -1;
                else 
                	return 0;
            }
        });
		
				
		for(int i = 0; i < dsTongSoDu.size(); i++) {
			int index = dsTongSoDu.get(i).getIndex();
			//System.out.println(index);
			//System.out.println(dsTongSoDu.get(i).getTongSoDu());
			System.out.println(nganHangTemp.getDSKhachHang().get(index).getMaKhachHang());
		}
		
	}
	
	public void inKhachHangCoLuotGiaoDichNhieuNhat(ArrayList<NganHang> DSNganHang) {
		Scanner sc = new Scanner(System.in);
		System.out.println("nhap id ngan hang");
		String maNganHang = sc.nextLine();
		//tim ngan hang
		NganHang nganHangTemp = null;
		for(int i = 0; i < DSNganHang.size(); i++) {
			if(maNganHang.equals(DSNganHang.get(i).getMaChiNhanh())){
				nganHangTemp = DSNganHang.get(i);
				break;
			}
		}
		//neu ngan hang khong ton tai
		if(nganHangTemp == null) {
			System.out.println("ngan hang ban nhap khong ton tai");
			return;
		}
		int max = 0;
		int maxIndex = 0;
		for(int i = 0; i < nganHangTemp.getDSKhachHang().size(); i++) {
			KhachHang khachHangTemp = nganHangTemp.getDSKhachHang().get(i);
			
			
			for(int j = 0; j < khachHangTemp.getDSTaiKhoan().size(); j++) {
				TaiKhoan taiKhoanTemp = khachHangTemp.getDSTaiKhoan().get(j);
				if(taiKhoanTemp.getDSGiaoDich().size() > max) {
					max = taiKhoanTemp.getDSGiaoDich().size();
					maxIndex = j;
				}
			}
			
			
		}
		
		
		System.out.println(nganHangTemp.getDSKhachHang().get(maxIndex));
	}
}
