package baitap;

import java.util.ArrayList;
import java.util.Scanner;



public class Main{

	
	
	private static Scanner sc;

	public static void main(String[] args) {
		
		ChucNang chucNang = new ChucNang();
		sc = new Scanner(System.in);
		ArrayList<NganHang> DSNganHang = new ArrayList<NganHang>();
		
		DSNganHang.add(new NganHang());
		DSNganHang.add(new NganHang());
		DSNganHang.add(new NganHang());
		
		
		DSNganHang.get(0).setMaChiNhanh("1");
		DSNganHang.get(1).setMaChiNhanh("2");
		DSNganHang.get(2).setMaChiNhanh("3");
		
		DSNganHang.get(0).setTenChiNhanh("chi nhanh a");
		DSNganHang.get(1).setTenChiNhanh("chi nhanh b");
		DSNganHang.get(2).setTenChiNhanh("chi nhanh c");
		
		DSNganHang.get(0).setDiaChi("12w");
		DSNganHang.get(1).setDiaChi("15q");
		DSNganHang.get(2).setDiaChi("25f");
		
		ArrayList<TaiKhoan> dsTaiKhoanA = new ArrayList<TaiKhoan>();
		dsTaiKhoanA.add(new TaiKhoan("tk1",50,new ArrayList<GiaoDich>()));
		dsTaiKhoanA.add(new TaiKhoan("tk2",40,new ArrayList<GiaoDich>()));
		
		ArrayList<TaiKhoan> dsTaiKhoanB = new ArrayList<TaiKhoan>();
		dsTaiKhoanB.add(new TaiKhoan("tk1",60,new ArrayList<GiaoDich>()));
		dsTaiKhoanB.add(new TaiKhoan("tk2",50,new ArrayList<GiaoDich>()));
		
		ArrayList<TaiKhoan> dsTaiKhoanC = new ArrayList<TaiKhoan>();
		dsTaiKhoanC.add(new TaiKhoan("tk1",30,new ArrayList<GiaoDich>()));
		dsTaiKhoanC.add(new TaiKhoan("tk2",50,new ArrayList<GiaoDich>()));
		
		ArrayList<KhachHang> dsKhachHangs = new ArrayList<KhachHang>();
		dsKhachHangs.add(new KhachHang("kh1", "kha", new DiaChi("a","b","c","d"), dsTaiKhoanA));
		dsKhachHangs.add(new KhachHang("kh2", "khb", new DiaChi("a","b","c","d"), dsTaiKhoanB));
		dsKhachHangs.add(new KhachHang("kh3", "khc", new DiaChi("a","b","c","d"), dsTaiKhoanC));
		DSNganHang.get(0).setDSKhachHang(dsKhachHangs);
		
		
		while (true) {
	        int chose;
	        System.out.println("1)khai bao 1 chi nhanh\n" +
	                "2)nhap nhieu khach hang vao mot chi nhanh ngan hang\n" +
	                "3)nhap nhieu tai khoan vao mot khach hang\n" +
	                "4)in ra tat ca giao dich cua tat ca tai khoan cua tat ca khach hang trong 1 chi nhanh\n" +
	                "5) liet ke tat ca cac tai khoan co so du lon nhat cua tung khach hang trong chi nhanh \n" +
	                "6)sap xep theo so du va in ra thong tin khach hang \n" +
	                "7)hien thi khach hang co tong giao dich nhieu nhat"+
	                "\t\t\t\t chọn");
	               
					chose = sc.nextInt();
	                switch (chose){
	                case 0:
                        System.exit(0);
	                case 1:
	                	
	                	chucNang.nhapChiNhanh(DSNganHang);
	                	break;
	                case 2:
	                	chucNang.nhapKhachHang(DSNganHang);
	                	break;
	                case 3:
	                	chucNang.nhapTaiKhoan(DSNganHang);
	                	break;
	                case 4:
	                	chucNang.xuatChiNhanh(DSNganHang);
	                	break;
	                case 5:
	                	chucNang.xuatKhachHang(DSNganHang);
	                	break;
	                case 6:
	                	chucNang.GuiRutTien(DSNganHang);
	                	break;
	                case 7:
	                	chucNang.inGiaoDich(DSNganHang);
	                	break;
	                case 8:
                        chucNang.inTaiKhoanCoSoDuLonNhat(DSNganHang);
                        break;
	                case 9:
                        chucNang.inTangDungTheoTongSoDu(DSNganHang);
                        break;
	                case 10:
	                	chucNang.inKhachHangCoLuotGiaoDichNhieuNhat(DSNganHang);
	                	break;
                    default:
                        System.out.println("khong ton tai chuc nang\n");
                        break;
	                }
	                }
    }
	
	
		
	
			
		
		
		
	


}	


